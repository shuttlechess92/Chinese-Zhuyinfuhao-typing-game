#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include "zhuyin.h"
#include "game_one.h"

using namespace std;







int main()

{

	
	// initialize the vowels

	/*b b;
	p p;
	m m;
	f f;
	d d;
	t t;
	n n;
	l l;
	g g;
	k k;
	h h;
	j j;
	q q;
	x x;
	zh zh;
	ch ch;
	sh sh;
	r r;
	z z;
	c c;
	s s;
	y y;
	w w;
	yu yu;
	a a;
	o o; 
	e e;
	eh eh;
	ai ai;
	ei ei;
	ao ao;
	ou ou;
	an an;
	en en;
	ang ang;
	eng eng;
	er er;*/
	//------------------------------------------------------
	/*
	time_t start;
	time(&start);
	timer(start, 60);*/
	Game_one();

/*	b.display();
char answer;
	cin>> answer;
*/


}

